﻿namespace BlazorToastNotifications.Services;

public enum ToastLevel
{
    Info,
    Success,
    Warning,
    Error
}